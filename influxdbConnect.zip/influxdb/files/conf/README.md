Place your InfluxDB&trade; configuration file here. These will not be used in case the value *existingConfiguration* is used.

More information can be found in the link below:

- [InfluxDB&trade; Configuration File](https://github.com/bitnami/bitnami-docker-influxdb#configuration-file)
