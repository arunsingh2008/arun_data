You can copy here your custom `.sh` or `.txt` files so they are executed during the first boot of the image.

More info in the [bitnami-docker-influxdb](https://github.com/bitnami/bitnami-docker-influxdb#initializing-a-new-instance) repository.
